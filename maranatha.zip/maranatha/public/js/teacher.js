// Maranatha High School — Teacher dashboard
(function () {
  const user = Auth.requireRole('teacher');
  if (!user) return;

  const menu = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'students', label: 'My Students' },
    { id: 'attendance', label: 'Take Attendance' },
    { id: 'grades', label: 'Enter Grades' },
    { id: 'announcements', label: 'Announcements' }
  ];
  UI.mountShell(user, menu, ['dashboard']);

  let studentsCache = [];

  async function loadDashboard() {
    try {
      const [allStudents, att, ann] = await Promise.all([
        API.get('/api/students'),
        API.get('/api/attendance?date=' + UI.today()),
        API.get('/api/announcements')
      ]);
      studentsCache = allStudents;
      const marked = att.records.filter(r => r.status);
      const present = marked.filter(r => r.status === 'present').length;
      const rate = marked.length ? Math.round((present / marked.length) * 100) : 0;

      document.getElementById('dashStats').innerHTML = `
        <div class="stat-card"><div class="label">My Students</div><div class="value">${allStudents.length}</div></div>
        <div class="stat-card"><div class="label">Attendance Today</div><div class="value">${rate}%</div></div>
        <div class="stat-card"><div class="label">Announcements</div><div class="value">${ann.length}</div></div>
      `;
      document.getElementById('dashAnnouncements').innerHTML = ann.slice(0, 3).map(a => `
        <div class="announcement-card">
          <h3>${UI.esc(a.title)}</h3>
          <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
          <p>${UI.esc(a.body)}</p>
        </div>`).join('') || '<p style="color:#6b7280">No announcements yet.</p>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadStudents() {
    try {
      const all = await API.get('/api/students');
      studentsCache = all;
      document.getElementById('studentsBody').innerHTML = all.map(s => `
        <tr>
          <td>${UI.esc(s.id)}</td><td>${UI.esc(s.name)}</td>
          <td>${UI.esc(s.class_name)}</td><td>${UI.esc(s.campus)}</td>
          <td>${UI.esc(s.guardian)}</td>
        </tr>
      `).join('');
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadAttendance() {
    try {
      const date = document.getElementById('attDate').value || UI.today();
      const res = await API.get('/api/attendance?date=' + date);
      document.getElementById('attendanceBody').innerHTML = res.records.map(r => `
        <tr data-sid="${r.student_id}">
          <td>${UI.esc(r.student_id)}</td><td>${UI.esc(r.name)}</td>
          <td>
            <select class="att-status">
              <option value="" ${!r.status ? 'selected' : ''}>—</option>
              <option value="present" ${r.status === 'present' ? 'selected' : ''}>present</option>
              <option value="absent" ${r.status === 'absent' ? 'selected' : ''}>absent</option>
              <option value="late" ${r.status === 'late' ? 'selected' : ''}>late</option>
            </select>
          </td>
        </tr>
      `).join('');
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.getElementById('markAllPresent').addEventListener('click', () => {
    document.querySelectorAll('.att-status').forEach(s => s.value = 'present');
  });

  document.getElementById('saveAttendance').addEventListener('click', async () => {
    try {
      const date = document.getElementById('attDate').value || UI.today();
      const rows = [...document.querySelectorAll('#attendanceBody tr')];
      const records = rows.map(tr => ({
        student_id: tr.dataset.sid,
        status: tr.querySelector('.att-status').value
      })).filter(r => r.status);
      if (!records.length) return UI.toast('Nothing to save', 'error');
      await API.post('/api/attendance', { date, records });
      UI.toast('Attendance saved', 'success');
      loadAttendance();
    } catch (e) { UI.toast(e.message, 'error'); }
  });

  document.getElementById('attDate').addEventListener('change', loadAttendance);

  document.getElementById('gradeForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const sid = document.getElementById('gStudent').value.trim();
    try {
      await API.post('/api/grades/' + sid, {
        subject: document.getElementById('gSubject').value,
        term: document.getElementById('gTerm').value,
        ca: Number(document.getElementById('gCA').value),
        exam: Number(document.getElementById('gExam').value)
      });
      UI.toast('Grade saved', 'success');
      document.getElementById('gradeForm').reset();
    } catch (e2) { UI.toast(e2.message, 'error'); }
  });

  async function loadAnnouncements() {
    try {
      const items = await API.get('/api/announcements');
      document.getElementById('annList').innerHTML = items.map(a => `
        <div class="announcement-card">
          <h3>${UI.esc(a.title)}</h3>
          <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
          <p>${UI.esc(a.body)}</p>
        </div>`).join('') || '<p style="color:#6b7280">No announcements yet.</p>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.getElementById('annForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await API.post('/api/announcements', {
        title: document.getElementById('annTitle').value,
        body: document.getElementById('annBody').value
      });
      UI.toast('Posted', 'success');
      document.getElementById('annForm').reset();
      loadAnnouncements();
    } catch (e2) { UI.toast(e2.message, 'error'); }
  });

  document.addEventListener('page:shown', (e) => {
    const p = e.detail;
    if (p === 'dashboard') loadDashboard();
    else if (p === 'students') loadStudents();
    else if (p === 'attendance') { document.getElementById('attDate').value = UI.today(); loadAttendance(); }
    else if (p === 'announcements') loadAnnouncements();
  });

  loadDashboard();
})();