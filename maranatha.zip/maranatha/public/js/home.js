// Maranatha High School — Home page
(async function () {
  const list = document.getElementById('announcementsList');
  try {
    const items = await API.get('/api/announcements');
    if (!items.length) {
      list.innerHTML = '<p style="color:#6b7280">No announcements yet.</p>';
      return;
    }
    list.innerHTML = items.slice(0, 6).map(a => `
      <div class="announcement-card">
        <h3>${UI.esc(a.title)}</h3>
        <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
        <p>${UI.esc(a.body)}</p>
      </div>
    `).join('');
  } catch (e) {
    list.innerHTML = '<p style="color:#dc2626">Could not load announcements: ' + UI.esc(e.message) + '</p>';
  }
})();