// Maranatha High School — Frontend auth helpers
window.Auth = (() => {
  const USER_KEY = 'maranatha_user';

  function save(token, user) {
    API.setToken(token);
    sessionStorage.setItem(USER_KEY, JSON.stringify(user));
  }
  function getUser() {
    try { return JSON.parse(sessionStorage.getItem(USER_KEY) || 'null'); }
    catch (_) { return null; }
  }
  function logout() {
    API.setToken(null);
    sessionStorage.removeItem(USER_KEY);
    window.location.href = '/login.html';
  }
  function requireRole(...roles) {
    const u = getUser();
    if (!u) { window.location.href = '/login.html'; return null; }
    if (roles.length && !roles.includes(u.role)) {
      alert('Access denied');
      window.location.href = '/login.html';
      return null;
    }
    return u;
  }
  return { save, getUser, logout, requireRole };
})();