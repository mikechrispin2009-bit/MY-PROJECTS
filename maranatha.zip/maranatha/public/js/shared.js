// Maranatha High School — Shared UI helpers
window.UI = (() => {
  function toast(msg, kind) {
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('show'), 30);
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 300);
    }, 3200);
  }

  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
    );
  }

  function money(n) {
    return '₦' + Number(n || 0).toLocaleString();
  }

  function today() {
    return new Date().toISOString().slice(0, 10);
  }

  function toggleSidebar() {
    const s = document.querySelector('.sidebar');
    if (s) s.classList.toggle('open');
  }

  // Sidebar + topbar wire-up for dashboards
  function mountShell(user, menu, pageIds) {
    // Sidebar brand
    const brand = document.querySelector('.sidebar .brand');
    if (brand) brand.innerHTML = 'Maranatha <span>High School</span>';

    const nav = document.querySelector('.sidebar nav');
    if (nav) {
      nav.innerHTML = menu.map(m =>
        `<a data-page="${m.id}" class="${m.id === pageIds[0] ? 'active' : ''}">
           <span>${esc(m.label)}</span>
           ${m.badge ? `<span class="badge" data-badge="${m.badge}" style="display:none">0</span>` : ''}
         </a>`
      ).join('');

      nav.querySelectorAll('a[data-page]').forEach(a => {
        a.addEventListener('click', () => {
          nav.querySelectorAll('a').forEach(x => x.classList.remove('active'));
          a.classList.add('active');
          document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
          const target = document.querySelector('.page[data-page="' + a.dataset.page + '"]');
          if (target) target.classList.add('active');
          const title = document.querySelector('.topbar .page-title');
          if (title) title.textContent = a.textContent.trim().split('\n')[0];
          // notify page
          document.dispatchEvent(new CustomEvent('page:shown', { detail: a.dataset.page }));
        });
      });
    }

    // Topbar user
    const av = document.querySelector('.topbar .avatar');
    if (av) av.textContent = user.initials || user.full_name.slice(0, 2).toUpperCase();
    const un = document.querySelector('.topbar .u-name');
    if (un) un.textContent = user.full_name;
    const ur = document.querySelector('.topbar .u-role');
    if (ur) ur.textContent = user.role;

    // Sign out
    const so = document.querySelector('.sidebar .signout');
    if (so) so.addEventListener('click', () => Auth.logout());

    // Hamburger
    const h = document.querySelector('.topbar .hamburger');
    if (h) h.addEventListener('click', toggleSidebar);
  }

  // Build a generic table body
  function tableRows(items, renderRow, emptyMsg) {
    if (!items || !items.length) {
      return `<tr><td colspan="20" class="empty-note">${esc(emptyMsg || 'No records')}</td></tr>`;
    }
    return items.map(renderRow).join('');
  }

  return { toast, esc, money, today, toggleSidebar, mountShell, tableRows };
})();