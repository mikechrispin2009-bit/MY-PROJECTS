// Maranatha High School — API client
window.API = (() => {
  const TOKEN_KEY = 'maranatha_token';

  function getToken() {
    return sessionStorage.getItem(TOKEN_KEY) || null;
  }
  function setToken(t) {
    if (t) sessionStorage.setItem(TOKEN_KEY, t);
    else sessionStorage.removeItem(TOKEN_KEY);
  }

  async function call(method, url, body) {
    const headers = { 'Content-Type': 'application/json' };
    const t = getToken();
    if (t) headers['Authorization'] = 'Bearer ' + t;

    const opts = { method, headers };
    if (body !== undefined) opts.body = JSON.stringify(body);

    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (_) { data = {}; }
    if (!res.ok) {
      const err = new Error(data.error || `HTTP ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  return {
    getToken, setToken,
    get:    (url)       => call('GET', url),
    post:   (url, body) => call('POST', url, body),
    put:    (url, body) => call('PUT', url, body),
    del:    (url)       => call('DELETE', url)
  };
})();