// Maranatha High School — Public Student Portal (PS001)
(async function () {
  const SID = 'PS001';

  async function loadStudent() {
    try {
      const [students, grades, fees] = await Promise.all([
        API.get('/api/students'),
        API.get('/api/grades/' + SID),
        API.get('/api/fees')
      ]);
      const me = students.find(s => s.id === SID);
      if (!me) throw new Error('Student not found');

      document.getElementById('studentName').textContent = me.name;
      document.getElementById('studentMeta').textContent =
        me.class_name + ' · ' + me.campus + ' Campus · Guardian: ' + me.guardian;

      // Fee stat
      const f = fees.find(x => x.id === SID) || { fees_total: 0, fees_paid: 0, balance: 0 };
      document.getElementById('feeStats').innerHTML = `
        <div class="stat-card"><div class="label">Total Fees</div><div class="value">${UI.money(f.fees_total)}</div></div>
        <div class="stat-card"><div class="label">Paid</div><div class="value">${UI.money(f.fees_paid)}</div></div>
        <div class="stat-card"><div class="label">Balance</div><div class="value" style="color:${Number(f.balance) > 0 ? '#dc2626' : '#16a34a'}">${UI.money(f.balance)}</div></div>
      `;

      // Grades
      const gb = document.getElementById('gradesBody');
      if (!grades.grades.length) {
        gb.innerHTML = '<tr><td colspan="6" class="empty-note">No grades yet</td></tr>';
      } else {
        gb.innerHTML = grades.grades.map(g => `
          <tr>
            <td>${UI.esc(g.subject)}</td>
            <td>${UI.esc(g.term)}</td>
            <td>${g.ca}/30</td>
            <td>${g.exam}/70</td>
            <td><strong>${g.total}</strong></td>
            <td><span class="pill ${g.letter === 'A' || g.letter === 'B' ? 'ok' : g.letter === 'F' ? 'bad' : 'warn'}">${g.letter}</span></td>
          </tr>
        `).join('');
      }
    } catch (e) {
      document.getElementById('studentName').textContent = 'Error';
      document.getElementById('studentMeta').textContent = e.message;
    }
  }

  async function loadAttendance() {
    try {
      // show latest 14 days
      const dates = [];
      for (let i = 0; i < 14; i++) {
        const d = new Date(); d.setDate(d.getDate() - i);
        dates.push(d.toISOString().slice(0, 10));
      }
      const results = await Promise.all(dates.map(d => API.get('/api/attendance?date=' + d)));
      const ab = document.getElementById('attBody');
      const rows = [];
      results.forEach(r => {
        const rec = r.records.find(x => x.student_id === SID);
        if (rec && rec.status) rows.push({ date: r.date, status: rec.status });
      });
      if (!rows.length) {
        ab.innerHTML = '<tr><td colspan="2" class="empty-note">No attendance recorded yet</td></tr>';
      } else {
        ab.innerHTML = rows.map(x => `
          <tr>
            <td>${x.date}</td>
            <td><span class="pill ${x.status === 'present' ? 'ok' : x.status === 'late' ? 'warn' : 'bad'}">${x.status}</span></td>
          </tr>
        `).join('');
      }
    } catch (e) {
      document.getElementById('attBody').innerHTML =
        '<tr><td colspan="2" class="empty-note">' + UI.esc(e.message) + '</td></tr>';
    }
  }

  loadStudent();
  loadAttendance();
})();