// Maranatha High School — Parent dashboard (scoped to PS001)
(function () {
  const user = Auth.requireRole('parent');
  if (!user) return;

  const menu = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'grades', label: 'Child Grades' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'fees', label: 'Fees' },
    { id: 'announcements', label: 'Announcements' }
  ];
  UI.mountShell(user, menu, ['dashboard']);

  const SID = 'PS001';

  async function loadDashboard() {
    try {
      const [fees, ann] = await Promise.all([
        API.get('/api/fees'),
        API.get('/api/announcements')
      ]);
      const f = fees.find(x => x.id === SID) || { fees_total: 0, fees_paid: 0, balance: 0 };
      document.getElementById('dashStats').innerHTML = `
        <div class="stat-card"><div class="label">Total Fees</div><div class="value">${UI.money(f.fees_total)}</div></div>
        <div class="stat-card"><div class="label">Paid</div><div class="value">${UI.money(f.fees_paid)}</div></div>
        <div class="stat-card"><div class="label">Balance</div><div class="value" style="color:${Number(f.balance) > 0 ? '#dc2626' : '#16a34a'}">${UI.money(f.balance)}</div></div>
      `;
      document.getElementById('dashAnnouncements').innerHTML = ann.slice(0, 3).map(a => `
        <div class="announcement-card">
          <h3>${UI.esc(a.title)}</h3>
          <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
          <p>${UI.esc(a.body)}</p>
        </div>`).join('') || '<p style="color:#6b7280">No announcements.</p>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadGrades() {
    try {
      const res = await API.get('/api/grades/' + SID);
      document.getElementById('gradesBody').innerHTML = res.grades.length ? res.grades.map(g => `
        <tr>
          <td>${UI.esc(g.subject)}</td><td>${UI.esc(g.term)}</td>
          <td>${g.ca}/30</td><td>${g.exam}/70</td><td><strong>${g.total}</strong></td>
          <td><span class="pill ${g.letter === 'A' || g.letter === 'B' ? 'ok' : g.letter === 'F' ? 'bad' : 'warn'}">${g.letter}</span></td>
        </tr>`).join('') : '<tr><td colspan="6" class="empty-note">No grades yet</td></tr>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadAttendance() {
    try {
      const dates = [];
      for (let i = 0; i < 14; i++) {
        const d = new Date(); d.setDate(d.getDate() - i);
        dates.push(d.toISOString().slice(0, 10));
      }
      const results = await Promise.all(dates.map(d => API.get('/api/attendance?date=' + d)));
      const rows = [];
      results.forEach(r => {
        const rec = r.records.find(x => x.student_id === SID);
        if (rec && rec.status) rows.push({ date: r.date, status: rec.status });
      });
      document.getElementById('attBody').innerHTML = rows.length ? rows.map(x => `
        <tr><td>${x.date}</td>
        <td><span class="pill ${x.status === 'present' ? 'ok' : x.status === 'late' ? 'warn' : 'bad'}">${x.status}</span></td></tr>
      `).join('') : '<tr><td colspan="2" class="empty-note">No attendance recorded yet</td></tr>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadFees() {
    try {
      const rows = await API.get('/api/fees');
      const f = rows.find(x => x.id === SID);
      if (!f) return document.getElementById('feesBody').innerHTML = 'Student not found';
      document.getElementById('feesBody').innerHTML = `
        <div class="stats-row">
          <div class="stat-card"><div class="label">Total</div><div class="value">${UI.money(f.fees_total)}</div></div>
          <div class="stat-card"><div class="label">Paid</div><div class="value">${UI.money(f.fees_paid)}</div></div>
          <div class="stat-card"><div class="label">Balance</div><div class="value" style="color:${Number(f.balance) > 0 ? '#dc2626' : '#16a34a'}">${UI.money(f.balance)}</div></div>
        </div>`;
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function loadAnnouncements() {
    try {
      const items = await API.get('/api/announcements');
      document.getElementById('annList').innerHTML = items.map(a => `
        <div class="announcement-card">
          <h3>${UI.esc(a.title)}</h3>
          <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
          <p>${UI.esc(a.body)}</p>
        </div>`).join('') || '<p style="color:#6b7280">No announcements yet.</p>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.addEventListener('page:shown', (e) => {
    const p = e.detail;
    if (p === 'dashboard') loadDashboard();
    else if (p === 'grades') loadGrades();
    else if (p === 'attendance') loadAttendance();
    else if (p === 'fees') loadFees();
    else if (p === 'announcements') loadAnnouncements();
  });

  loadDashboard();
})();