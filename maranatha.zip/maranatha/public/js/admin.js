// Maranatha High School — Admin dashboard
(function () {
  const user = Auth.requireRole('admin');
  if (!user) return;

  const menu = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'students', label: 'Students' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'grades', label: 'Grades' },
    { id: 'fees', label: 'Fees' },
    { id: 'registrations', label: 'Registrations', badge: 'regs' },
    { id: 'announcements', label: 'Announcements' }
  ];
  UI.mountShell(user, menu, ['dashboard']);

  // ----- Modal helpers -----
  const modal = document.getElementById('modalBackdrop');
  const modalBody = document.getElementById('modalBody');
  function openModal(html) { modalBody.innerHTML = html; modal.classList.add('show'); }
  function closeModal() { modal.classList.remove('show'); modalBody.innerHTML = ''; }
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });

  // ----- Data cache -----
  let students = [];
  let pendingRegs = [];

  async function refreshBadge() {
    try {
      pendingRegs = await API.get('/api/auth/registrations');
      const b = document.querySelector('.badge[data-badge="regs"]');
      if (b) {
        if (pendingRegs.length) { b.textContent = pendingRegs.length; b.style.display = 'inline-block'; }
        else b.style.display = 'none';
      }
    } catch (_) {}
  }

  // ---- Dashboard ----
  async function loadDashboard() {
    try {
      const [allStudents, fees, ann] = await Promise.all([
        API.get('/api/students'),
        API.get('/api/fees'),
        API.get('/api/announcements')
      ]);
      students = allStudents;

      const totalStudents = allStudents.length;
      const totalFees = fees.reduce((a, f) => a + Number(f.fees_total), 0);
      const paid = fees.reduce((a, f) => a + Number(f.fees_paid), 0);
      const outstanding = totalFees - paid;

      // Attendance rate for today
      const today = UI.today();
      const att = await API.get('/api/attendance?date=' + today);
      const marked = att.records.filter(r => r.status);
      const present = marked.filter(r => r.status === 'present').length;
      const rate = marked.length ? Math.round((present / marked.length) * 100) : 0;

      document.getElementById('dashStats').innerHTML = `
        <div class="stat-card"><div class="label">Students</div><div class="value">${totalStudents}</div></div>
        <div class="stat-card"><div class="label">Attendance Rate (Today)</div><div class="value">${rate}%</div></div>
        <div class="stat-card"><div class="label">Fees Collected</div><div class="value">${UI.money(paid)}</div></div>
        <div class="stat-card"><div class="label">Outstanding</div><div class="value" style="color:${outstanding > 0 ? '#dc2626' : '#16a34a'}">${UI.money(outstanding)}</div></div>
      `;

      document.getElementById('dashAnnouncements').innerHTML = ann.length
        ? ann.slice(0, 3).map(a => `
            <div class="announcement-card">
              <h3>${UI.esc(a.title)}</h3>
              <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
              <p>${UI.esc(a.body)}</p>
            </div>`).join('')
        : '<p style="color:#6b7280">No announcements yet.</p>';

      document.getElementById('dashStudents').innerHTML = fees.slice(0, 5).map(f => `
        <tr>
          <td>${UI.esc(f.id)}</td><td>${UI.esc(f.name)}</td><td>${UI.esc(f.class_name)}</td>
          <td>${UI.esc(f.campus)}</td>
          <td><strong style="color:${Number(f.balance) > 0 ? '#dc2626' : '#16a34a'}">${UI.money(f.balance)}</strong></td>
        </tr>
      `).join('');
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  // ---- Students ----
  async function loadStudents() {
    try {
      const q = document.getElementById('studentSearch').value.trim();
      students = await API.get('/api/students' + (q ? '?q=' + encodeURIComponent(q) : ''));
      document.getElementById('studentsBody').innerHTML = students.map(s => `
        <tr>
          <td>${UI.esc(s.id)}</td>
          <td>${UI.esc(s.name)}</td>
          <td>${UI.esc(s.class_name)}</td>
          <td>${UI.esc(s.campus)}</td>
          <td>${UI.esc(s.guardian)}</td>
          <td>${UI.esc(s.phone)}</td>
          <td>
            <button class="btn ghost sm" data-edit="${s.id}">Edit</button>
            <button class="btn danger sm" data-del="${s.id}">Delete</button>
          </td>
        </tr>
      `).join('');

      document.querySelectorAll('[data-edit]').forEach(b =>
        b.addEventListener('click', () => editStudent(b.dataset.edit)));
      document.querySelectorAll('[data-del]').forEach(b =>
        b.addEventListener('click', () => deleteStudent(b.dataset.del)));
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  function studentForm(s) {
    s = s || {};
    return `
      <h3>${s.id ? 'Edit Student' : 'Add Student'}</h3>
      <div class="reg-grid" style="margin-top:16px">
        <div class="field full"><label>Name</label><input id="f_name" value="${UI.esc(s.name || '')}" required></div>
        <div class="field"><label>Class</label><input id="f_class" value="${UI.esc(s.class_name || '')}" required></div>
        <div class="field"><label>Campus</label>
          <select id="f_campus">
            ${['Ipaja', 'Ayobo', 'Ikola'].map(c => `<option ${s.campus === c ? 'selected' : ''}>${c}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Guardian</label><input id="f_guardian" value="${UI.esc(s.guardian || '')}" required></div>
        <div class="field"><label>Phone</label><input id="f_phone" value="${UI.esc(s.phone || '')}" required></div>
        <div class="field"><label>Total Fees (₦)</label><input id="f_fees" type="number" value="${s.fees_total || 0}"></div>
      </div>
      <div class="modal-actions">
        <button class="btn ghost" onclick="document.getElementById('modalBackdrop').classList.remove('show')">Cancel</button>
        <button class="btn accent" id="saveStudentBtn">Save</button>
      </div>`;
  }

  function addStudent() {
    openModal(studentForm(null));
    document.getElementById('saveStudentBtn').addEventListener('click', async () => {
      try {
        await API.post('/api/students', {
          name: document.getElementById('f_name').value,
          class_name: document.getElementById('f_class').value,
          campus: document.getElementById('f_campus').value,
          guardian: document.getElementById('f_guardian').value,
          phone: document.getElementById('f_phone').value,
          fees_total: Number(document.getElementById('f_fees').value) || 0
        });
        UI.toast('Student added', 'success');
        closeModal();
        loadStudents();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  function editStudent(id) {
    const s = students.find(x => x.id === id);
    if (!s) return;
    openModal(studentForm(s));
    document.getElementById('saveStudentBtn').addEventListener('click', async () => {
      try {
        await API.put('/api/students/' + id, {
          name: document.getElementById('f_name').value,
          class_name: document.getElementById('f_class').value,
          campus: document.getElementById('f_campus').value,
          guardian: document.getElementById('f_guardian').value,
          phone: document.getElementById('f_phone').value,
          fees_total: Number(document.getElementById('f_fees').value) || 0
        });
        UI.toast('Student updated', 'success');
        closeModal();
        loadStudents();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  async function deleteStudent(id) {
    if (!confirm('Delete student ' + id + '? This cannot be undone.')) return;
    try {
      await API.del('/api/students/' + id);
      UI.toast('Deleted', 'success');
      loadStudents();
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  // ---- Attendance ----
  async function loadAttendance() {
    try {
      const date = document.getElementById('attDate').value || UI.today();
      const res = await API.get('/api/attendance?date=' + date);
      document.getElementById('attendanceBody').innerHTML = res.records.map(r => `
        <tr data-sid="${r.student_id}">
          <td>${UI.esc(r.student_id)}</td>
          <td>${UI.esc(r.name)}</td>
          <td>
            <select class="att-status">
              <option value="" ${!r.status ? 'selected' : ''}>—</option>
              <option value="present" ${r.status === 'present' ? 'selected' : ''}>present</option>
              <option value="absent" ${r.status === 'absent' ? 'selected' : ''}>absent</option>
              <option value="late" ${r.status === 'late' ? 'selected' : ''}>late</option>
            </select>
          </td>
        </tr>
      `).join('');
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.getElementById('markAllPresent').addEventListener('click', () => {
    document.querySelectorAll('.att-status').forEach(s => s.value = 'present');
  });

  document.getElementById('saveAttendance').addEventListener('click', async () => {
    try {
      const date = document.getElementById('attDate').value || UI.today();
      const rows = [...document.querySelectorAll('#attendanceBody tr')];
      const records = rows.map(tr => ({
        student_id: tr.dataset.sid,
        status: tr.querySelector('.att-status').value
      })).filter(r => r.status);
      if (!records.length) return UI.toast('Nothing to save', 'error');
      await API.post('/api/attendance', { date, records });
      UI.toast('Attendance saved', 'success');
      loadAttendance();
    } catch (e) { UI.toast(e.message, 'error'); }
  });

  document.getElementById('attDate').addEventListener('change', loadAttendance);

  // ---- Grades ----
  async function loadGradesSummary() {
    try {
      const rows = await API.get('/api/grades/summary/all');
      document.getElementById('gradesSummaryBody').innerHTML = rows.map(r => `
        <tr>
          <td>${UI.esc(r.id)}</td><td>${UI.esc(r.name)}</td><td>${UI.esc(r.class_name)}</td>
          <td>${r.subject_count}</td><td>${r.total_score}</td><td>${r.avg_score || 0}</td>
        </tr>
      `).join('') || '<tr><td colspan="6" class="empty-note">No grades yet</td></tr>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.getElementById('gradeForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const sid = document.getElementById('gStudent').value.trim();
    try {
      await API.post('/api/grades/' + sid, {
        subject: document.getElementById('gSubject').value,
        term: document.getElementById('gTerm').value,
        ca: Number(document.getElementById('gCA').value),
        exam: Number(document.getElementById('gExam').value)
      });
      UI.toast('Grade saved', 'success');
      document.getElementById('gradeForm').reset();
      loadGradesSummary();
    } catch (e2) { UI.toast(e2.message, 'error'); }
  });

  // ---- Fees ----
  async function loadFees() {
    try {
      const rows = await API.get('/api/fees');
      document.getElementById('feesBody').innerHTML = rows.map(f => `
        <tr>
          <td>${UI.esc(f.id)}</td><td>${UI.esc(f.name)}</td>
          <td>${UI.money(f.fees_total)}</td><td>${UI.money(f.fees_paid)}</td>
          <td><strong style="color:${Number(f.balance) > 0 ? '#dc2626' : '#16a34a'}">${UI.money(f.balance)}</strong></td>
          <td><button class="btn accent sm" data-pay="${f.id}">Record Payment</button></td>
        </tr>
      `).join('');
      document.querySelectorAll('[data-pay]').forEach(b =>
        b.addEventListener('click', () => recordPayment(b.dataset.pay)));
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  function recordPayment(sid) {
    openModal(`
      <h3>Record Payment</h3>
      <p class="sub">Student: <strong>${sid}</strong></p>
      <div class="field"><label>Amount (₦)</label><input id="payAmt" type="number" min="1" required></div>
      <div class="field"><label>Note (optional)</label><input id="payNote" /></div>
      <div class="modal-actions">
        <button class="btn ghost" onclick="document.getElementById('modalBackdrop').classList.remove('show')">Cancel</button>
        <button class="btn accent" id="payBtn">Record</button>
      </div>`);
    document.getElementById('payBtn').addEventListener('click', async () => {
      try {
        const amount = Number(document.getElementById('payAmt').value);
        await API.post('/api/fees/' + sid + '/pay', { amount, note: document.getElementById('payNote').value || null });
        UI.toast('Payment recorded', 'success');
        closeModal();
        loadFees();
        loadDashboard();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  // ---- Registrations ----
  async function loadRegistrations() {
    await refreshBadge();
    try {
      document.getElementById('regsBody').innerHTML = pendingRegs.length ? pendingRegs.map(r => `
        <tr>
          <td>${UI.esc(r.full_name)}</td><td>${UI.esc(r.username)}</td><td>${UI.esc(r.email)}</td>
          <td>${UI.esc(r.subject || '—')}</td><td>${UI.esc(r.campus)}</td>
          <td>
            <button class="btn accent sm" data-approve="${r.id}">Approve</button>
            <button class="btn danger sm" data-reject="${r.id}">Reject</button>
          </td>
        </tr>
      `).join('') : '<tr><td colspan="6" class="empty-note">No pending registrations</td></tr>';

      document.querySelectorAll('[data-approve]').forEach(b =>
        b.addEventListener('click', () => approveReg(b.dataset.approve)));
      document.querySelectorAll('[data-reject]').forEach(b =>
        b.addEventListener('click', () => rejectReg(b.dataset.reject)));
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  function approveReg(id) {
    openModal(`
      <h3>Approve Teacher</h3>
      <p class="sub">Optionally assign a class (e.g. Year 11).</p>
      <div class="field"><label>Class (optional)</label><input id="apClass" placeholder="Year 11" /></div>
      <div class="modal-actions">
        <button class="btn ghost" onclick="document.getElementById('modalBackdrop').classList.remove('show')">Cancel</button>
        <button class="btn accent" id="apBtn">Approve</button>
      </div>`);
    document.getElementById('apBtn').addEventListener('click', async () => {
      try {
        await API.post('/api/auth/registrations/' + id + '/approve', {
          class_name: document.getElementById('apClass').value.trim() || null
        });
        UI.toast('Teacher approved', 'success');
        closeModal(); loadRegistrations(); refreshBadge();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  function rejectReg(id) {
    openModal(`
      <h3>Reject Registration</h3>
      <div class="field"><label>Reason (optional)</label><input id="rjNote" /></div>
      <div class="modal-actions">
        <button class="btn ghost" onclick="document.getElementById('modalBackdrop').classList.remove('show')">Cancel</button>
        <button class="btn danger" id="rjBtn">Reject</button>
      </div>`);
    document.getElementById('rjBtn').addEventListener('click', async () => {
      try {
        await API.post('/api/auth/registrations/' + id + '/reject', {
          note: document.getElementById('rjNote').value.trim() || null
        });
        UI.toast('Registration rejected', 'success');
        closeModal(); loadRegistrations(); refreshBadge();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  // ---- Announcements ----
  async function loadAnnouncements() {
    try {
      const items = await API.get('/api/announcements');
      document.getElementById('annList').innerHTML = items.map(a => `
        <div class="announcement-card">
          <h3>${UI.esc(a.title)}</h3>
          <div class="meta">${UI.esc(a.posted_by)} · ${new Date(a.posted_at).toLocaleString()}</div>
          <p>${UI.esc(a.body)}</p>
        </div>`).join('') || '<p style="color:#6b7280">No announcements yet.</p>';
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  document.getElementById('annForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await API.post('/api/announcements', {
        title: document.getElementById('annTitle').value,
        body: document.getElementById('annBody').value
      });
      UI.toast('Announcement posted', 'success');
      document.getElementById('annForm').reset();
      loadAnnouncements();
    } catch (e2) { UI.toast(e2.message, 'error'); }
  });

  // ---- Wire page switching ----
  document.addEventListener('page:shown', (e) => {
    const p = e.detail;
    if (p === 'dashboard') loadDashboard();
    else if (p === 'students') loadStudents();
    else if (p === 'attendance') { document.getElementById('attDate').value = UI.today(); loadAttendance(); }
    else if (p === 'grades') loadGradesSummary();
    else if (p === 'fees') loadFees();
    else if (p === 'registrations') loadRegistrations();
    else if (p === 'announcements') loadAnnouncements();
  });

  document.getElementById('studentSearch').addEventListener('input', loadStudents);
  document.getElementById('addStudentBtn').addEventListener('click', addStudent);

  // Initial
  loadDashboard();
  refreshBadge();
})();