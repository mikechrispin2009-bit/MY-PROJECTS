-- Maranatha High School — Database Schema
DROP DATABASE IF EXISTS maranatha;
CREATE DATABASE maranatha CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE maranatha;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  role ENUM('admin','teacher','student','parent') NOT NULL,
  initials VARCHAR(4) NOT NULL,
  class_name VARCHAR(20) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE teacher_registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  phone VARCHAR(30) NOT NULL,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  subject VARCHAR(80) NULL,
  campus ENUM('Ipaja','Ayobo','Ikola') NOT NULL,
  qualification VARCHAR(120) NULL,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  reviewed_by INT NULL,
  reviewed_at TIMESTAMP NULL,
  rejection_note VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE students (
  id VARCHAR(12) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  class_name VARCHAR(20) NOT NULL,
  campus ENUM('Ipaja','Ayobo','Ikola') NOT NULL,
  guardian VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  fees_total DECIMAL(10,2) DEFAULT 0,
  fees_paid DECIMAL(10,2) DEFAULT 0
);

CREATE TABLE attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(12) NOT NULL,
  date DATE NOT NULL,
  status ENUM('present','absent','late') NOT NULL,
  UNIQUE KEY uq_att (student_id, date),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE grades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(12) NOT NULL,
  subject VARCHAR(60) NOT NULL,
  term VARCHAR(20) NOT NULL,
  ca TINYINT UNSIGNED DEFAULT 0,
  exam TINYINT UNSIGNED DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(12) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_on DATE NOT NULL,
  note VARCHAR(255) NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  posted_by VARCHAR(120) NOT NULL,
  posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);