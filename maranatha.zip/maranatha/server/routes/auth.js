// Maranatha High School — Auth + teacher registration routes
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
require('dotenv').config();

const router = express.Router();
const SECRET = process.env.JWT_SECRET || 'dev-secret';
const EXPIRES = process.env.JWT_EXPIRES || '8h';

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: 'Username and password required' });
    const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const payload = {
      id: user.id, username: user.username, full_name: user.full_name,
      role: user.role, initials: user.initials, class_name: user.class_name
    };
    const token = jwt.sign(payload, SECRET, { expiresIn: EXPIRES });
    res.json({ token, user: payload });
  } catch (e) { next(e); }
});

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

// POST /api/auth/register-teacher (PUBLIC)
router.post('/register-teacher', async (req, res, next) => {
  try {
    const { full_name, email, phone, username, password, subject, campus, qualification } = req.body;
    if (!full_name || !email || !phone || !username || !password || !campus)
      return res.status(400).json({ error: 'Missing required fields' });
    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      `INSERT INTO teacher_registrations
       (full_name, email, phone, username, password_hash, subject, campus, qualification)
       VALUES (?,?,?,?,?,?,?,?)`,
      [full_name, email, phone, username, hash, subject || null, campus, qualification || null]
    );
    res.json({ ok: true, message: 'Registration submitted. Awaiting admin approval.' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Username or email already exists' });
    next(e);
  }
});

// GET /api/auth/registrations — pending only (admin)
router.get('/registrations', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, full_name, email, phone, username, subject, campus, qualification, created_at FROM teacher_registrations WHERE status='pending' ORDER BY created_at DESC"
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /api/auth/registrations/all — full history (admin)
router.get('/registrations/all', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, full_name, email, phone, username, subject, campus, qualification, status, rejection_note, reviewed_at, created_at FROM teacher_registrations ORDER BY created_at DESC"
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /api/auth/registrations/:id/approve (admin)
router.post('/registrations/:id/approve', requireAuth, requireRole('admin'), async (req, res, next) => {
  const conn = await pool.getConnection();
  try {
    const { class_name } = req.body || {};
    await conn.beginTransaction();
    const [rows] = await conn.query(
      "SELECT * FROM teacher_registrations WHERE id=? AND status='pending' FOR UPDATE",
      [req.params.id]
    );
    if (!rows.length) { await conn.rollback(); return res.status(404).json({ error: 'Pending registration not found' }); }
    const reg = rows[0];
    const initials = reg.full_name.split(/\s+/).map(w => w[0]).join('').slice(0, 4).toUpperCase();
    await conn.query(
      `INSERT INTO users (username, password_hash, full_name, role, initials, class_name)
       VALUES (?,?,?,?,?,?)`,
      [reg.username, reg.password_hash, reg.full_name, 'teacher', initials, class_name || null]
    );
    await conn.query(
      `UPDATE teacher_registrations SET status='approved', reviewed_by=?, reviewed_at=NOW() WHERE id=?`,
      [req.user.id, reg.id]
    );
    await conn.commit();
    res.json({ ok: true, message: `${reg.full_name} approved as teacher.` });
  } catch (e) {
    await conn.rollback();
    next(e);
  } finally {
    conn.release();
  }
});

// POST /api/auth/registrations/:id/reject (admin)
router.post('/registrations/:id/reject', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const { note } = req.body || {};
    const [result] = await pool.query(
      `UPDATE teacher_registrations SET status='rejected', reviewed_by=?, reviewed_at=NOW(), rejection_note=? WHERE id=? AND status='pending'`,
      [req.user.id, note || null, req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Pending registration not found' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;