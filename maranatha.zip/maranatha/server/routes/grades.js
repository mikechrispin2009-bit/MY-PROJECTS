// Maranatha High School — Grades routes
const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

function gradeLetter(total) {
  if (total >= 70) return 'A';
  if (total >= 60) return 'B';
  if (total >= 50) return 'C';
  if (total >= 40) return 'D';
  if (total >= 30) return 'E';
  return 'F';
}

// GET /api/grades/summary/all (admin/teacher)
router.get('/summary/all', requireAuth, requireRole('admin', 'teacher'), async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT s.id, s.name, s.class_name,
              COUNT(g.id) AS subject_count,
              COALESCE(SUM(g.ca),0) AS total_ca,
              COALESCE(SUM(g.exam),0) AS total_exam,
              COALESCE(SUM(g.ca+g.exam),0) AS total_score,
              ROUND(AVG(g.ca+g.exam),1) AS avg_score
       FROM students s LEFT JOIN grades g ON g.student_id = s.id
       GROUP BY s.id, s.name, s.class_name
       ORDER BY s.id`
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /api/grades/:studentId — PUBLIC read
router.get('/:studentId', async (req, res, next) => {
  try {
    const sid = req.params.studentId;
    const [student] = await pool.query('SELECT * FROM students WHERE id=?', [sid]);
    if (!student.length) return res.status(404).json({ error: 'Student not found' });
    const [rows] = await pool.query('SELECT * FROM grades WHERE student_id=? ORDER BY term, subject', [sid]);
    res.json({
      student: student[0],
      grades: rows.map(g => ({ ...g, total: g.ca + g.exam, letter: gradeLetter(g.ca + g.exam) }))
    });
  } catch (e) { next(e); }
});

// POST /api/grades/:studentId (admin/teacher)
router.post('/:studentId', requireAuth, requireRole('admin', 'teacher'), async (req, res, next) => {
  try {
    let { subject, term, ca, exam } = req.body;
    if (!subject || !term) return res.status(400).json({ error: 'subject and term required' });
    ca = Math.max(0, Math.min(30, Number(ca) || 0));
    exam = Math.max(0, Math.min(70, Number(exam) || 0));
    const [r] = await pool.query(
      'INSERT INTO grades (student_id, subject, term, ca, exam) VALUES (?,?,?,?,?)',
      [req.params.studentId, subject, term, ca, exam]
    );
    res.json({ id: r.insertId });
  } catch (e) { next(e); }
});

// DELETE /api/grades/id/:id (admin/teacher)
router.delete('/id/:id', requireAuth, requireRole('admin', 'teacher'), async (req, res, next) => {
  try {
    const [r] = await pool.query('DELETE FROM grades WHERE id=?', [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'Grade not found' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;