// Maranatha High School — Students routes
const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/students — PUBLIC read
router.get('/', async (req, res, next) => {
  try {
    const search = req.query.q ? `%${req.query.q}%` : null;
    let sql = 'SELECT * FROM students';
    const params = [];
    if (search) {
      sql += ' WHERE (name LIKE ? OR id LIKE ?)';
      params.push(search, search);
    }
    sql += ' ORDER BY id';
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /api/students (admin)
router.post('/', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const { name, class_name, campus, guardian, phone, fees_total } = req.body;
    if (!name || !class_name || !campus || !guardian || !phone)
      return res.status(400).json({ error: 'Missing required fields' });
    const [maxRows] = await pool.query("SELECT id FROM students ORDER BY id DESC LIMIT 1");
    const last = maxRows[0] ? parseInt(maxRows[0].id.slice(2)) : 0;
    const newId = 'PS' + String(last + 1).padStart(3, '0');
    await pool.query(
      `INSERT INTO students (id, name, class_name, campus, guardian, phone, fees_total, fees_paid)
       VALUES (?,?,?,?,?,?,?,0)`,
      [newId, name, class_name, campus, guardian, phone, Number(fees_total) || 0]
    );
    res.json({ id: newId });
  } catch (e) { next(e); }
});

// PUT /api/students/:id (admin)
router.put('/:id', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const { name, class_name, campus, guardian, phone, fees_total } = req.body;
    const [r] = await pool.query(
      `UPDATE students SET name=?, class_name=?, campus=?, guardian=?, phone=?, fees_total=? WHERE id=?`,
      [name, class_name, campus, guardian, phone, Number(fees_total) || 0, req.params.id]
    );
    if (!r.affectedRows) return res.status(404).json({ error: 'Student not found' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// DELETE /api/students/:id (admin)
router.delete('/:id', requireAuth, requireRole('admin'), async (req, res, next) => {
  try {
    const [r] = await pool.query('DELETE FROM students WHERE id=?', [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'Student not found' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;