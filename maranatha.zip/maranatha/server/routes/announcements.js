// Maranatha High School — Announcements routes
const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/announcements — PUBLIC read
router.get('/', async (req, res, next) => {
  try {
    const [rows] = await pool.query('SELECT * FROM announcements ORDER BY posted_at DESC LIMIT 50');
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /api/announcements (admin/teacher)
router.post('/', requireAuth, requireRole('admin', 'teacher'), async (req, res, next) => {
  try {
    const { title, body } = req.body;
    if (!title || !body) return res.status(400).json({ error: 'title and body required' });
    const [r] = await pool.query(
      'INSERT INTO announcements (title, body, posted_by) VALUES (?,?,?)',
      [title, body, req.user.full_name]
    );
    res.json({ id: r.insertId });
  } catch (e) { next(e); }
});

module.exports = router;