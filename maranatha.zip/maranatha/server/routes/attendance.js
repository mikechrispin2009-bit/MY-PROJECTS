// Maranatha High School — Attendance routes
const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/attendance?date=YYYY-MM-DD — PUBLIC read
router.get('/', async (req, res, next) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const [students] = await pool.query("SELECT id AS student_id, name FROM students ORDER BY id");
    const [existing] = await pool.query("SELECT student_id, status FROM attendance WHERE date=?", [date]);
    const map = Object.fromEntries(existing.map(r => [r.student_id, r.status]));
    res.json({
      date,
      records: students.map(s => ({ student_id: s.student_id, name: s.name, status: map[s.student_id] || null }))
    });
  } catch (e) { next(e); }
});

// POST /api/attendance — bulk upsert (admin/teacher)
router.post('/', requireAuth, requireRole('admin', 'teacher'), async (req, res, next) => {
  const { date, records } = req.body;
  if (!date || !Array.isArray(records)) return res.status(400).json({ error: 'date and records[] required' });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    for (const r of records) {
      if (!['present', 'absent', 'late'].includes(r.status)) continue;
      await conn.query(
        `INSERT INTO attendance (student_id, date, status) VALUES (?,?,?)
         ON DUPLICATE KEY UPDATE status=VALUES(status)`,
        [r.student_id, date, r.status]
      );
    }
    await conn.commit();
    res.json({ ok: true, count: records.length });
  } catch (e) {
    await conn.rollback();
    next(e);
  } finally {
    conn.release();
  }
});

module.exports = router;