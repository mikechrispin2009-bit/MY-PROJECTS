// Maranatha High School — Fees routes
const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/fees — PUBLIC read
router.get('/', async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, name, class_name, campus, fees_total, fees_paid,
              (fees_total - fees_paid) AS balance
       FROM students ORDER BY id`
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /api/fees/:studentId/pay (admin) — transactional
router.post('/:studentId/pay', requireAuth, requireRole('admin'), async (req, res, next) => {
  const amount = Number(req.body.amount);
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Valid amount required' });
  const note = req.body.note || null;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT * FROM students WHERE id=? FOR UPDATE', [req.params.studentId]);
    if (!rows.length) { await conn.rollback(); return res.status(404).json({ error: 'Student not found' }); }
    const s = rows[0];
    const newPaid = Number(s.fees_paid) + amount;
    if (newPaid > Number(s.fees_total)) {
      await conn.rollback();
      return res.status(400).json({ error: 'Payment exceeds total fees' });
    }
    await conn.query('UPDATE students SET fees_paid=? WHERE id=?', [newPaid, s.id]);
    await conn.query(
      'INSERT INTO payments (student_id, amount, paid_on, note) VALUES (?,?,CURDATE(),?)',
      [s.id, amount, note]
    );
    await conn.commit();
    res.json({ ok: true, new_paid: newPaid, balance: Number(s.fees_total) - newPaid });
  } catch (e) {
    await conn.rollback();
    next(e);
  } finally {
    conn.release();
  }
});

module.exports = router;