// Maranatha High School — Hash demo passwords
const bcrypt = require('bcryptjs');
const pool = require('./db');

async function seed() {
  const users = [
    { username: 'admin',   password: 'admin123'  },
    { username: 'teacher', password: 'teach123'  },
    { username: 'student', password: 'stud123'   },
    { username: 'parent',  password: 'parent123' }
  ];
  try {
    for (const u of users) {
      const hash = await bcrypt.hash(u.password, 10);
      await pool.query('UPDATE users SET password_hash = ? WHERE username = ?', [hash, u.username]);
      console.log(`✔ hashed ${u.username}`);
    }
    console.log('✅ Maranatha demo users seeded. You can now log in.');
    process.exit(0);
  } catch (e) {
    console.error('❌ Seed failed:', e.message);
    process.exit(1);
  }
}
seed();