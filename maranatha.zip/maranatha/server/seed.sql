-- Maranatha High School — Seed Data
USE maranatha;

INSERT INTO students (id, name, class_name, campus, guardian, phone, fees_total, fees_paid) VALUES
('PS001','Michael Dada','Year 11','Ipaja','Mr. Ade Dada','08012345678',120000,120000),
('PS002','Adetunji Taiwo','Year 10','Ayobo','Mrs. Bola Taiwo','08023456789',110000,70000),
('PS003','Zainab Bello','Year 9','Ikola','Alhaji Musa Bello','08034567890',100000,100000),
('PS004','Chidi Okonkwo','Year 8','Ipaja','Mr. Emeka Okonkwo','08045678901',95000,40000),
('PS005','Fatima Yusuf','Year 12','Ayobo','Hajia Aisha Yusuf','08056789012',135000,135000);

INSERT INTO announcements (title, body, posted_by) VALUES
('Welcome to Maranatha High School','We are delighted to welcome all students and parents to a new academic session at Maranatha High School. Please ensure all fees are cleared before the end of the first week.','Principal, Maranatha High School'),
('Parent-Teacher Meeting','Our first parent-teacher meeting this term will hold on the last Friday of this month at 10:00 AM in the main hall. Attendance is strongly encouraged.','Principal, Maranatha High School');

-- Placeholder users; seed-users.js overwrites hashes
INSERT INTO users (username, password_hash, full_name, role, initials, class_name) VALUES
('admin','REPLACE_ME','Maranatha Admin','admin','MA',NULL),
('teacher','REPLACE_ME','Mr. Tunde Adeyemi','teacher','TA','Year 11'),
('student','REPLACE_ME','Michael Dada','student','MD','Year 11'),
('parent','REPLACE_ME','Mr. Ade Dada','parent','AD',NULL);