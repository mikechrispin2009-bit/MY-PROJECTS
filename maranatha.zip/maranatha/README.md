# Maranatha High School Portal

Full-stack school management system for Maranatha High School.

## Stack
- Backend: Node.js + Express + MySQL (mysql2)
- Auth: JWT + bcrypt
- Frontend: Vanilla HTML/CSS/JS (multi-page)

## Demo Accounts
| Role    | Username | Password  |
|---------|----------|-----------|
| Admin   | admin    | admin123  |
| Teacher | teacher  | teach123  |
| Student | student  | stud123   |
| Parent  | parent   | parent123 |

## Quick Start
1. Start MySQL in XAMPP
2. Run `setup.bat`
3. Run `npm start`
4. Open http://localhost:3000

## Public Pages
- `/` — Home
- `/student-portal.html` — Public student view (PS001)
- `/login.html` — Login
- `/register.html` — Teacher registration

## Protected Dashboards
- `/admin.html`
- `/teacher.html`
- `/parent.html`