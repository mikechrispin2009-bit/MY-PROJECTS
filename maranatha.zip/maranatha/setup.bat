@echo off
REM ============================================
REM  Maranatha High School — Database Setup
REM  Requires XAMPP MySQL running as root (no password)
REM ============================================
setlocal

set MYSQL=C:\xampp\mysql\bin\mysql.exe
set PROJECT_DIR=%~dp0

echo.
echo ============================================
echo   MARANATHA HIGH SCHOOL - DATABASE SETUP
echo ============================================
echo.

if not exist "%MYSQL%" (
  echo [ERROR] MySQL not found at %MYSQL%
  echo Make sure XAMPP is installed at C:\xampp
  pause
  exit /b 1
)

echo [1/3] Loading schema...
"%MYSQL%" -u root < "%PROJECT_DIR%server\schema.sql"
if errorlevel 1 (
  echo [ERROR] Schema load failed. Is MySQL running in XAMPP?
  pause
  exit /b 1
)
echo        OK.

echo [2/3] Loading seed data...
"%MYSQL%" -u root < "%PROJECT_DIR%server\seed.sql"
if errorlevel 1 (
  echo [ERROR] Seed load failed.
  pause
  exit /b 1
)
echo        OK.

echo [3/3] Hashing demo passwords...
cd /d "%PROJECT_DIR%"
node server\seed-users.js
if errorlevel 1 (
  echo [ERROR] seed-users.js failed. Did you run npm install?
  pause
  exit /b 1
)
echo        OK.

echo.
echo ============================================
echo   DONE!
echo.
echo   Demo accounts:
echo     admin    / admin123
echo     teacher  / teach123
echo     student  / stud123
echo     parent   / parent123
echo.
echo   Now run:  npm start
echo   Then open: http://localhost:3000
echo ============================================
echo.
pause