
const express = require('express');
const app = express();
const port = 3000;
app.use(express.json());
let students = [
    {
        id: 1,
        name: "mike",
        gender: "male"
    }
];
app.post('/home', (req, res) => {
    const student2 = {
        id: req.body.id,
        name: req.body.name,
        gender: req.body.gender
    };
    students.push(student2);
    res.status(201).json(student2);
});
app.get('/home', (req, res) => {
    res.json(students);
});
app.get('/home/:id', (req, res) => {
    const studentId = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentId);
    if (!student) {
        return res.status(404).json({ message: 'Student not found' });
    }
    res.json(student);
});
app.put('/home/:id', (req, res) => {
    const studentId = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentId);
    if (!student) {
        return res.status(404).json({ message: 'Student not found' });
    }
    student.name = req.body.name;
    student.gender = req.body.gender;
    res.json(student);
});
app.delete('/home/:id', (req, res) => {
    const studentId = parseInt(req.params.id, 10);
    const studentindex = students.findIndex(i => i.id === studentId);
    if (studentindex === -1) {
        return res.status(404).json({ message: 'Student not found' });
    }
    const deletedStudent = students.splice(studentindex, 1);
    res.json({
        message: 'Student deleted successfully',
        student: deletedStudent[0]
    });
});
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
