<?php
$ fruits= array("apple", "Banana", "mango");
$ color= ["red", "green","blue"];
echo $ color[2];
echo $ color[0],[1],[2];
?>                                                                                                                                                                                                                                                                                                      