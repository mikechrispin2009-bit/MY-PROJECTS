const express = require('express');
const app = express();
const connection = require('./db');
app.use(express.json());
const port = process.env.PORT || 3000;
//create developers
app.post('/developers', (req, res) => {
    const{Names, sex, phone, district, school, trade, module, Degree, accountname}= req.body;
    const sql = 'INSERT INTO developers (Names, sex, phone, district, school, trade, module, Degree, accountname) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';  
    connection.query(sql, [Names, sex, phone, district, school, trade, module, Degree, accountname], (err, result) => {
        if (err) {
            console.error('Error inserting developer data:', err);
            res.status(500).json({ error: 'Failed to insert developer data' });
        } 
         return   res.status(201).json({ message: 'Developer data inserted successfully' });
        
    });
});
//READ ALL DEVELOPERS
app.get('/developers', (req, res) => {
    const sql = 'SELECT * FROM developers';
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching developer data:', err);
            res.status(500).json({ error: 'Failed to fetch developer data' });
        } 
           return res.status(200).json(results);
    });
});
//READ A SINGLE DEVELOPER
app.get('/developers/:id', (req, res) => {
    const {id} = req.params;
    const sql = 'SELECT * FROM developers WHERE id = ?';
    connection.query(sql, [id], (err, results) => {
        if (err) {
            console.error('Error fetching developer data:', err);
            res.status(500).json({ error: 'Failed to fetch developer data' });
        } 
        return res.status(200).json(results);
        
    });
});
//UPDATE A DEVELOPER
app.put('/developers/:id', (req, res) => {
    const {id} = req.params;
    const {Names, sex, phone, district, school, trade, module, Degree, accountname} = req.body;
    const sql = 'UPDATE developers SET Names = ?, sex = ?, phone = ?, district = ?, school = ?, trade = ?, module = ?, Degree = ?, accountname = ? WHERE id = ?';
    connection.query(sql, [Names, sex, phone, district, school, trade, module, Degree, accountname, id], (err, result) => {
        if (err) {
            console.error('Error updating developer data:', err);
            res.status(500).json({ error: 'Failed to update developer data' });
        } 
         
        return res.status(200).json({ message: 'Developer data updated successfully' });
        
    });
});
//DELETE A DEVELOPER
app.delete('/developers/:id', (req, res) => {
    const {id} = req.params;
    const sql = 'DELETE FROM developers WHERE id = ?';
    connection.query(sql, [id], (err, result) => {
        if (err) {
            console.error('Error deleting developer data:', err);
            res.status(500).json({ error: 'Failed to delete developer data' });
        }
         return res.status(200).json({ message: 'Developer data deleted successfully' });
        
    });
});
// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});