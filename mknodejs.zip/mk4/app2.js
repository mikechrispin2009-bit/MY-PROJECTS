
const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

let students = [];

app.post('/student', (req, res) => {
    const newstudent = {
        id: students.length + 1,
        name: req.body.name
    };

    students.push(newstudent);
    res.status(201).json(newstudent);
});

app.get('/student', (req, res) => {
    res.json(students);
});

app.get('/student/:id', (req, res) => {
    const studentid = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentid);

    if (!student) {
        return res.status(404).json({ message: 'student not found' });
    }

    res.json(student);
});

app.put('/student/:id', (req, res) => {
    const studentid = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentid);

    if (!student) {
        return res.status(404).json({ message: 'student not found' });
    }

    student.name = req.body.name;
    res.json(student);
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
