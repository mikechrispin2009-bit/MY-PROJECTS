let data = '';

const axios = require('axios');

axios.get('https://example.com')
  .then(response => {
    data += response.data;
    console.log(response.data);
  })
  .catch(error => {
    console.error('Error:', error);
  });