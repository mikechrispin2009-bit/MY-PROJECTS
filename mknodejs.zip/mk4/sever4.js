axios.get('http://127.0.0.1:3000')
  .then(response => {
    console.log('Response from server:', response.data.message);
  })
  .catch(error => {
    console.error('Error:', error);
  });