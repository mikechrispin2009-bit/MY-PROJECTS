const express=require('express');
const app= express();
const port= 3000;
app.use(express.Router.json());
let student={
    id:1,
    name:"mike",
    gender:"male"
};
app.post('/home', (req, res)=>
{
    const student2={
        id:req.body.id,
        name:req.body.name,
        gender:req.body.gender
    };
    student.push(student2);
    res.json(student2);
});

app.get('/home', (req, res)=>{
    res.json(student);
});


app.get('/home/:id', (req, res) => {
    const studentid = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentid);

    if (!student) {
        return res.status(404).json({ message: 'student not found' });
    }

    res.json(student);
});

app.put('/home/:id', (req, res) => {
    const studentid = parseInt(req.params.id, 10);
    const student = students.find(i => i.id === studentid);

    if (!student) {
        return res.status(404).json({ message: 'student not found' });
    }

    student.name = req.body.name;
    res.json(student);
});
app.delete('/student/:id', (req, res) => {
    const studentid = parseInt(req.params.id, 10);
    const studentindex = student.find(i => i.id === studentid);

    if (!studentindex) {
        return res.status(404).json({ message: 'student not found' });
    }

    student.name = req.body.name;
    res.json(studentindex,1);
});